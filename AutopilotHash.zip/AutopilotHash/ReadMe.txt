For Autopilot Hash button to function:
Include this folder and contents on the root of your boot image drive.